<?php
// Text
$_['text_title']           	= 'Payid19.Com USDT Payment Gateway';
// error
$_['text_error']     		= 'Payment Failed.';

$_['button_confirm']     = 'Confirm Payment!';
